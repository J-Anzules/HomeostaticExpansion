runs = 2000;
for i = 1:runs
    ModelandCellGrowth
end

